
<footer>
        &copy; phpacademy.org 2011. All rights reserved.
    </footer>