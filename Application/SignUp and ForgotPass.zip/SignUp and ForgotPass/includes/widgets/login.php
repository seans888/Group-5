 <div class="widget">
                <h2>Log-in</h2>
                <div class="inner">
                   <form action="login.php" method = "post">
				   <ul id ="login">
				   <li>
						Username:<br>
						<input type="text" name="username">
				   
				   </li>
				   <li>
						Password:<br>
						<input type="password" name="password">
						
				   </li>
				   <li>
					<input type="submit" name="Log in">
				   </li>
				   
				   <li>
					<a href ="register.php"> Register</a>
				   </li>
				   
				   <li>
					<a href ="changepassword.php"> Change Password</a>
				   </li
				   
				   <li>
					Forgotten your <a href="recover.php?mode=password">password</a>?
				   </li>
				 </ul>
			  </form>
           </div>
       </div>