 <div class="widget">
                <h2>Users</h2>
                <div class="inner">
				We current have x registered users.
      </div>
</div>