<?php
mail('rempsonpd@yahoo.com', 'Hello!', 'Hello, this is a test email', 'From: sao@apc.edu.ph');
?>