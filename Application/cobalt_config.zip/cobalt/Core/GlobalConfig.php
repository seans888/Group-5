<?php
/*
 * GlobalConfig.php
 * FRIDAY, November 28, 2006 
 * SCV2 global configuration file.
 * JV Roig
 */
define("FULLPATH_CORE", dirname(__FILE__) . '/');
define("LOGIN_PAGE", '/cobalt/index.php');
define("HOME_PAGE", '/cobalt/main.php');
define("INDEX_TARGET", '/cobalt/main.php');
define("SHOW_SQL_ERRORS", TRUE);
define("EXPORT_DIRECTORY", 'Exports');
define("TIMEZONE", 'Asia/Manila');
?>
