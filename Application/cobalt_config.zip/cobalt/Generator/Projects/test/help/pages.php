<?php
//List of modules (tables) for the table of contents to show
//The format is doc_subclass_name => doc_dir_name
$content_pages = array(
        'adviser_doc'=>'adviser',
        'calevent_doc'=>'calevent',
        'docrequest_doc'=>'docrequest',
        'document_doc'=>'document',
        'org_doc'=>'org',
        'org_rep_doc'=>'org_rep',
        'sao_doc'=>'sao',
        'student_affair_head_doc'=>'student_affair_head',
);