<?php
$config = array(
                ['location'=>'modules/test/add_adviser.php',
                'pre'=>'adviser_sst_add.php',
                'post'=>''],
               );

$_SESSION['sst']['tasks'] = $config;