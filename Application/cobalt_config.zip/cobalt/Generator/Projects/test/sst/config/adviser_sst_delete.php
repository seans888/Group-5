<?php
$config = array(
                ['location'=>'modules/test/delete_adviser.php',
                'pre'=>'adviser_sst_delete.php',
                'post'=>''],
               );

$_SESSION['sst']['tasks'] = $config;