<?php
$config = array(
                ['location'=>'modules/test/detailview_adviser.php',
                'pre'=>'adviser_sst_detailview.php',
                'post'=>''],
               );

$_SESSION['sst']['tasks'] = $config;