<?php
$config = array(
                ['location'=>'modules/test/edit_adviser.php',
                'pre'=>'adviser_sst_edit.php',
                'post'=>''],
               );

$_SESSION['sst']['tasks'] = $config;