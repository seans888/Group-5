<?php
$config = array(
                ['location'=>'modules/test/add_calevent.php',
                'pre'=>'calevent_sst_add.php',
                'post'=>''],
               );

$_SESSION['sst']['tasks'] = $config;