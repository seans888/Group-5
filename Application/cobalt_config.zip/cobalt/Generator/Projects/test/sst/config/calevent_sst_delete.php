<?php
$config = array(
                ['location'=>'modules/test/delete_calevent.php',
                'pre'=>'calevent_sst_delete.php',
                'post'=>''],
               );

$_SESSION['sst']['tasks'] = $config;