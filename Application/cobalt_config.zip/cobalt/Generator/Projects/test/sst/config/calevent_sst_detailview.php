<?php
$config = array(
                ['location'=>'modules/test/detailview_calevent.php',
                'pre'=>'calevent_sst_detailview.php',
                'post'=>''],
               );

$_SESSION['sst']['tasks'] = $config;