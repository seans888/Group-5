<?php
$config = array(
                ['location'=>'modules/test/edit_calevent.php',
                'pre'=>'calevent_sst_edit.php',
                'post'=>''],
               );

$_SESSION['sst']['tasks'] = $config;