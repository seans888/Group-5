<?php
$config = array(
                ['location'=>'modules/test/add_docrequest.php',
                'pre'=>'docrequest_sst_add.php',
                'post'=>''],
               );

$_SESSION['sst']['tasks'] = $config;