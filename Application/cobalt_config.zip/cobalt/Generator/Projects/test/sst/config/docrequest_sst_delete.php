<?php
$config = array(
                ['location'=>'modules/test/delete_docrequest.php',
                'pre'=>'docrequest_sst_delete.php',
                'post'=>''],
               );

$_SESSION['sst']['tasks'] = $config;