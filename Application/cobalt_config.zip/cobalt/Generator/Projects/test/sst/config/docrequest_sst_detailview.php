<?php
$config = array(
                ['location'=>'modules/test/detailview_docrequest.php',
                'pre'=>'docrequest_sst_detailview.php',
                'post'=>''],
               );

$_SESSION['sst']['tasks'] = $config;