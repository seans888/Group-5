<?php
$config = array(
                ['location'=>'modules/test/edit_docrequest.php',
                'pre'=>'docrequest_sst_edit.php',
                'post'=>''],
               );

$_SESSION['sst']['tasks'] = $config;