<?php
$config = array(
                ['location'=>'modules/test/add_document.php',
                'pre'=>'document_sst_add.php',
                'post'=>''],
               );

$_SESSION['sst']['tasks'] = $config;