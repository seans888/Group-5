<?php
$config = array(
                ['location'=>'modules/test/detailview_document.php',
                'pre'=>'document_sst_detailview.php',
                'post'=>''],
               );

$_SESSION['sst']['tasks'] = $config;