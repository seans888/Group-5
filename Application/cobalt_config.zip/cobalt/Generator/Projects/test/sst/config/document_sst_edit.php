<?php
$config = array(
                ['location'=>'modules/test/edit_document.php',
                'pre'=>'document_sst_edit.php',
                'post'=>''],
               );

$_SESSION['sst']['tasks'] = $config;