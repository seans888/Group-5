<?php
$config = array(
                ['location'=>'modules/test/add_org_rep.php',
                'pre'=>'org_rep_sst_add.php',
                'post'=>''],
               );

$_SESSION['sst']['tasks'] = $config;