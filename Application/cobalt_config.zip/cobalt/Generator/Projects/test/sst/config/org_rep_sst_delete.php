<?php
$config = array(
                ['location'=>'modules/test/delete_org_rep.php',
                'pre'=>'org_rep_sst_delete.php',
                'post'=>''],
               );

$_SESSION['sst']['tasks'] = $config;