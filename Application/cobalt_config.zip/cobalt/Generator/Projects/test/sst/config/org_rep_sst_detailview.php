<?php
$config = array(
                ['location'=>'modules/test/detailview_org_rep.php',
                'pre'=>'org_rep_sst_detailview.php',
                'post'=>''],
               );

$_SESSION['sst']['tasks'] = $config;