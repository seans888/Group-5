<?php
$config = array(
                ['location'=>'modules/test/edit_org_rep.php',
                'pre'=>'org_rep_sst_edit.php',
                'post'=>''],
               );

$_SESSION['sst']['tasks'] = $config;