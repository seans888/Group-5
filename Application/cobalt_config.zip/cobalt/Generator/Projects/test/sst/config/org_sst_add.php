<?php
$config = array(
                ['location'=>'modules/test/add_org.php',
                'pre'=>'org_sst_add.php',
                'post'=>''],
               );

$_SESSION['sst']['tasks'] = $config;