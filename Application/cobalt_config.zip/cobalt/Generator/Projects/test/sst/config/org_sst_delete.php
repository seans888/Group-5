<?php
$config = array(
                ['location'=>'modules/test/delete_org.php',
                'pre'=>'org_sst_delete.php',
                'post'=>''],
               );

$_SESSION['sst']['tasks'] = $config;