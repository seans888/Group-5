<?php
$config = array(
                ['location'=>'modules/test/detailview_org.php',
                'pre'=>'org_sst_detailview.php',
                'post'=>''],
               );

$_SESSION['sst']['tasks'] = $config;