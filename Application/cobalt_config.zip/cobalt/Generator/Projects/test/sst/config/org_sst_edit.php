<?php
$config = array(
                ['location'=>'modules/test/edit_org.php',
                'pre'=>'org_sst_edit.php',
                'post'=>''],
               );

$_SESSION['sst']['tasks'] = $config;