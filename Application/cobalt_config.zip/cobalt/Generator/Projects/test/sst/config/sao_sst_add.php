<?php
$config = array(
                ['location'=>'modules/test/add_sao.php',
                'pre'=>'sao_sst_add.php',
                'post'=>''],
               );

$_SESSION['sst']['tasks'] = $config;