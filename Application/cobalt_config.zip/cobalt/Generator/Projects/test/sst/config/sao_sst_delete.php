<?php
$config = array(
                ['location'=>'modules/test/delete_sao.php',
                'pre'=>'sao_sst_delete.php',
                'post'=>''],
               );

$_SESSION['sst']['tasks'] = $config;