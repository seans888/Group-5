<?php
$config = array(
                ['location'=>'modules/test/detailview_sao.php',
                'pre'=>'sao_sst_detailview.php',
                'post'=>''],
               );

$_SESSION['sst']['tasks'] = $config;