<?php
$config = array(
                ['location'=>'modules/test/edit_sao.php',
                'pre'=>'sao_sst_edit.php',
                'post'=>''],
               );

$_SESSION['sst']['tasks'] = $config;