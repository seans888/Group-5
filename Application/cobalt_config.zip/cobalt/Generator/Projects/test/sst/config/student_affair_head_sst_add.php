<?php
$config = array(
                ['location'=>'modules/test/add_student_affair_head.php',
                'pre'=>'student_affair_head_sst_add.php',
                'post'=>''],
               );

$_SESSION['sst']['tasks'] = $config;