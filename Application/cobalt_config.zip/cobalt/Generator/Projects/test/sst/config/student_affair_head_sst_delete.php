<?php
$config = array(
                ['location'=>'modules/test/delete_student_affair_head.php',
                'pre'=>'student_affair_head_sst_delete.php',
                'post'=>''],
               );

$_SESSION['sst']['tasks'] = $config;