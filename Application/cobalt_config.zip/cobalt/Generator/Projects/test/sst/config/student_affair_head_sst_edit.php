<?php
$config = array(
                ['location'=>'modules/test/edit_student_affair_head.php',
                'pre'=>'student_affair_head_sst_edit.php',
                'post'=>''],
               );

$_SESSION['sst']['tasks'] = $config;