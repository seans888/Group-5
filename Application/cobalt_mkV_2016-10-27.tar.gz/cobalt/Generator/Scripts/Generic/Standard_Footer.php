<?php

function createStandardFooter()
{
    $content=<<<EOD

\$html->draw_footer();
EOD;
    return $content;
}
