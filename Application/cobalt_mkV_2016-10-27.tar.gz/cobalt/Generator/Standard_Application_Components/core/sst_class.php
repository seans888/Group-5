<?php
require 'base_sst_class.php';
class sst extends base_sst
{

}
