<?php
//List of modules (tables) for the table of contents to show
//The format is doc_subclass_name => doc_dir_name
$content_pages = array(
    'award_doc'=>'award',
    'salary_grade_doc'=>'salary_grade',
    'positions_doc'=>'position',
    'office_docs_doc'=>'office_docs',
);