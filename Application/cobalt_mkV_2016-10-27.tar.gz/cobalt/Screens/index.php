<?php
header("location: ../main.php");
