<?php
define('COBALT_MAJOR_VERSION', 'mkV');
define('COBALT_BUILD_VERSION', '2016-10-27');